<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sms_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
else{
 // echo "Connected successfully";
}

if(isset($_POST['submit'])){

	if(!empty($_POST['funame'])  && !empty($_POST['faname']) && !empty($_POST['cnic']) && !empty($_POST['mno'])   && !empty($_POST['pno'])   && !empty($_POST['dob'])    && !empty($_POST['email'])   && !empty($_POST['city'])){
 $name = $_POST["funame"];
 $fathername = $_POST["faname"];
 $cnic = $_POST["cnic"];
 $mobno = $_POST["mno"];
 $ptcl = $_POST["pno"];
 $dob = $_POST["dob"];
 $email= $_POST["email"];
 $city = $_POST["city"];

 $query = "INSERT INTO admission_form (applicant_name, father_name, applicant_cnic, mobile_no, ptcl_no, date_of_birth, e_mail,	 
           city)  
          values('$name', '$fathername', '$cnic',  '$mobno', ' $ptcl','$dob', '$email', '$city')";

		$run = mysqli_query($conn, $query) or die(mysql_error());
       
		if($run){
			echo "Form Submited Successfully";
		}
		else {
			echo "Form Not Submited";
		}
	}
		else {
			echo "All Fields Required";
		}
}

?>	