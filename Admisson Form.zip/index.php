<html>
<head>
<title>Admission Form</title>
 </head>
 <body>
  <form action="index1.php" method="post">
 	<h1 align="center" style= "border:8px solid black;"><b>GOVERNEMENT COLLEGE UNIVERSITY FSD</b><br>
 		ONLINE APPLICATION & BIODATA FORM</h1>

   
 		<table  border=0 style=" background-color:#bbff ; width:90% " align=center>
 			<h2 align="center" style= "border:5px solid black;"><b>PERSONAL INFORMATION</b><br>
 		</h2>
 			<tr style="width: 100%"><td colspan="7">
 			<p style= "font-size:140%;" align="left"><b>Applicant Full Name:</b></p><input type="text" name="funame" style="width:100%">
 			</td>

          
        <td colspan="6">
 			<p  style= "font-size:140%;" align="left"><b>Father Name:</b></p> <input type="text" name="faname" style="width: 80%">
 			</td></tr>


 			<tr><td colspan="4">
 				<p style= "font-size:120%;" align="left"><b>Applicant CNIC:</b></p><input type="text" name="cnic" style="width: 60%">
 			</td>
 			<td colspan="4">
 				<p style= "font-size:120%;" align="left"><b>Mobile No:</b></p><input type="text" name="mno" style="width: 60%">
 			</td>
 			<td colspan="4">
 				<p style= "font-size:120%;" align="left"><b> PTCL No:</b></p><input type="text" name="pno"  style="width: 60%">
 			</td>
 		</tr>

 		<tr><td colspan="4">
 			
 				<p style= "font-size:120%;" align="left"><b> Date of Birth:</b></p><input type="text" name="dob" style="width: 60%">
 			</td>
 			<td colspan="4">
 				<p style= "font-size:120%;" align="left"><b>Email Adress:</b></p><input type="text" name="email" style="width: 60%">
 			</td>
 			<td colspan="4">
 				<p style= "font-size:120%;" align="left"><b>City:</b></p><input type="text" name="city" style="width: 60%">
 			</td>

 		</td></tr>
 		<tr><td colspan="2" >
      <br>
      <br>
 		
 				<button type="submit" name="submit" style="margin-left: 110%"value= "submit">Submit</button>
   
    </select>
            </td></tr>
</table>
 </body>
 </html>